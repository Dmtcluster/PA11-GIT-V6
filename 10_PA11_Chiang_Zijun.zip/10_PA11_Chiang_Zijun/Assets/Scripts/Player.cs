﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;
public class Player : MonoBehaviour
{
    public static Player thisPlayer;
    public float speed;
    public float score;
    public Text txtscore;
    // Start is called before the first frame update
    void Start()
    {
        thisPlayer = this;
    }

    // Update is called once per frame
    void Update()
    {      
        float verticalInput = Input.GetAxis("Vertical");
        if (transform.position.y <= 4 && transform.position.y >= -4) 
        transform.position = transform.position + new Vector3(0 , verticalInput * speed * Time.deltaTime, 0);
        transform.position = new Vector3(0, Mathf.Clamp(transform.position.y,-4,4), -0.04771193f);

        txtscore.text = "Score : " + score;
    }

    public void AddScore()
    {
        score++;
    }

}
