﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class GoalScript : MonoBehaviour
{
    public Text ScoreText;
    private int Score;
    // Start is called before the first frame update
    void Start()
    {
        Score = 0;
    }

    private void OnCollisionEnter(Collision collision)
    {
        if(collision.gameObject.tag == "Obstacle")
        {
            Score++;
            ScoreText.text = "Score: " + Score;
            Destroy(collision.gameObject);
        }
    }
}
